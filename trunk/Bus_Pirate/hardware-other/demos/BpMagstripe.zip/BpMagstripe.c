/* Author: James Stephenson, mjs@openweb.co.za
 * This program interfaces the Bus Pirate to track 2 TTL magstripe readers that
 * have a clock and data line and optionally a card present line, the reader can
 * be powered form the Bus Pirate but this isn't necessary (remember to hook up
 * the ground line though). The default config is to read data on the negative
 * going clock pulse of an active low clock and data line. Connect the CS pin
 * to the card present pin, CLK to the RCP pin and RDP to MOSI.
 * (Tested with firmware v4.1)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

#define BINLEN 300

#define FBINARY		1
#define FRAW 		2
#define FRAWV		4
#define FTERMINATE	8
#define FINVERT		16

unsigned char flags = 0;

int find_sentinels(unsigned char *bin_buf, unsigned char **ss, unsigned char **sts, unsigned char **lst){
	int loop, binstrlen;
	
	*ss = *sts = *lst = 0;

	if(!(*ss = strstr(bin_buf, "11010")))
		return 0;
	
	binstrlen = strlen(bin_buf);
	for(loop = *ss-bin_buf; loop + 5 < binstrlen; loop += 5){
		if(!strncmp(bin_buf+loop, "11111", 5) && !(*sts))
			*sts = bin_buf+loop;
		if(strncmp(bin_buf+loop, "00000", 5))
			*lst = bin_buf+loop;
	}

	if(!(*sts))
		return 0;

	if(*sts == *ss + 5)
		return 0;

	return 1;
}

int process_code(unsigned char *bin_buf){
	unsigned char *ss, *sts, *lst, tmp_bin_buf[BINLEN], dta[] = "0123456789:;<=>?", lrc = 0;
	int loop, loop2, looplen, bitcount, char_count;

	if(!find_sentinels(bin_buf, &ss, &sts, &lst)){
		memset(tmp_bin_buf, 0, BINLEN);
		for(loop = 0, looplen = strlen(bin_buf); loop < looplen; loop++)
			tmp_bin_buf[loop] = bin_buf[looplen-loop-1];
		if(!find_sentinels(tmp_bin_buf, &ss, &sts, &lst))
			return 0;
		bin_buf = tmp_bin_buf;
	}

	for(loop = 0, looplen = (lst-ss)/5; loop <= looplen; loop++){
		for(loop2 = 0, bitcount = 0; loop2 < 5; loop2++)
			bitcount += ss[loop*5+loop2];
		if(!(bitcount%2))
			printf("*");
		else{
			char_count = ((ss[loop*5]=='1')?1:0) | ((ss[loop*5 + 1]=='1')?2:0) | ((ss[loop*5 + 2]=='1')?4:0) | ((ss[loop*5 + 3]=='1')?8:0);
			printf("%c", dta[char_count]);
			lrc ^= char_count;
			if(char_count == 15 && !(flags & FRAW)){ //if end sentinel
				for(loop2 = 0, bitcount = 0; loop2 < 4; loop2++)
					bitcount += (lrc>>loop2)&1;
				lrc |= (bitcount%2)?0:16;
				char_count = ((ss[loop*5 + 5]=='1')?1:0) | ((ss[loop*5 + 6]=='1')?2:0) | ((ss[loop*5 + 7]=='1')?4:0) | ((ss[loop*5 + 8]=='1')?8:0) | ((ss[loop*5 + 9]=='1')?16:0);
				if(lrc != char_count)
					printf(" [LRC FAILED]");
				if(sts + 5 != lst)
					printf(" [MORE DATA]");
				printf("\n");
				return 1;
			}else if(char_count == 15 && flags & FRAWV)
				break;
		}
	}
	printf("\n");
	
	return 1;
}

int main(int argc, char **argv){
	DCB my_dcb;
	HANDLE hComm;
	long int bytes_written, bytes_received, cur_char = 0, loop, looplen;
	unsigned char receive_buf[6], bin_buf[BINLEN], hex_val[5], cur_byte;
	
	if(argc < 2 || argc > 6){
		printf("BpMagstripe (com?) [-r] [-i] [-t] [-b]\n"
			   "r - show raw data, use twice for single frame\n"
			   "i - invert all bits\n"
			   "t - terminate after reading one swipe\n"
			   "b - binary output only");
		return 1;		
	}

	for(loop = 2; loop < argc; loop++){
		switch(argv[loop][1]){
			case('r'):
				if(flags & FRAW)
					flags |= FRAWV;
				else
					flags |= FRAW;
				break;
			case('i'):flags |= FINVERT;
				break;
			case('t'):flags |= FTERMINATE;
				break;
			case('b'):flags |= FBINARY;
				break;
			default:
				printf("Argument error\n");
				return 2;
		}
	}

	hComm = CreateFile(argv[1], GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	if(hComm == INVALID_HANDLE_VALUE){
		printf("Error Opening Serial Port\n");
		return 3;
	}

	my_dcb.DCBlength = sizeof(my_dcb);
	GetCommState(hComm, &my_dcb);
	my_dcb.BaudRate = CBR_115200;
	my_dcb.ByteSize = 8;
	my_dcb.StopBits = ONESTOPBIT;
	my_dcb.Parity = NOPARITY;

	if(!SetCommState(hComm, &my_dcb)){
		printf("Error setting up serial port\n");
		return 4;
	}
	
	WriteFile(hComm, "#\n", 2, &bytes_written, 0); //reset BP
	sleep(10);
	WriteFile(hComm, "m\n", 2, &bytes_written, 0); //set mode
	sleep(10);
	WriteFile(hComm, "5\n", 2, &bytes_written, 0); //spi
	sleep(10);
	WriteFile(hComm, "4\n", 2, &bytes_written, 0); //1MHz
	sleep(10);
	WriteFile(hComm, "2\n", 2, &bytes_written, 0); //clock idle high
	sleep(10);
	WriteFile(hComm, "2\n", 2, &bytes_written, 0); //clock active to idle
	sleep(10);
	WriteFile(hComm, "2\n", 2, &bytes_written, 0); //sample at end
	sleep(10);
	WriteFile(hComm, "1\n", 2, &bytes_written, 0); //open drain
	sleep(10);
	WriteFile(hComm, "W\n", 2, &bytes_written, 0); //turn on power supplies
	sleep(10);
	WriteFile(hComm, "(1)\n", 4, &bytes_written, 0); //sniffer macro
	sleep(10);
	WriteFile(hComm, "1\n", 2, &bytes_written, 0); //sniff on cs low
	sleep(10);	
	
	while(ReadFile(hComm, receive_buf, 1, &bytes_received, 0) && receive_buf[0] != '[');
	memset(bin_buf, 0, BINLEN);
	hex_val[4] = 0;	
	while(1){
		ReadFile(hComm, receive_buf, 1, &bytes_received, 0);
		if(receive_buf[0] == '[')
			continue;
		else if(receive_buf[0] == ']'){
			if(!cur_char)
				continue;
			if(flags & FINVERT){
				for(loop = 0; looplen = strlen(bin_buf), loop < looplen; loop++)
					if(bin_buf[loop] == '0')
						bin_buf[loop] = '1';
					else
						bin_buf[loop] = '0';
			}
			if(flags & FBINARY)
				printf("%s\n\n", bin_buf);
			else if(!process_code(bin_buf))
				printf("Start and stop sentinels not found\n");
			if(flags & FTERMINATE)
				return 5;
			memset(bin_buf, 0, BINLEN);
			cur_char = 0;
			continue;
		}
		hex_val[0] = '0';
		ReadFile(hComm, hex_val+1, 3, &bytes_received, 0);
		sscanf(hex_val, "%x", &cur_byte);
		ReadFile(hComm, receive_buf, 6, &bytes_received, 0);
		for(loop = 0; loop < 8 && cur_char+loop < BINLEN-1; loop++){
			bin_buf[cur_char+loop] = (cur_byte&128)?'0':'1';
			cur_byte <<= 1;
		}
		cur_char += loop;
	}	

	return 0;
}
